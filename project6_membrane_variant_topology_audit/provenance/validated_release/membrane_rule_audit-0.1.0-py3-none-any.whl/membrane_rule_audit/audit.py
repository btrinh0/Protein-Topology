"""Reusable analysis of mutation-score contrasts near membrane boundaries.

Point this at any predictor's scores and a membrane-topology census, and it answers
three questions for each of the four charge rules:

1. **Side difference.** Within a single residue, does the predictor score a charge
   change differently on the cytosolic and outer flanks? Measured as a within-site
   penalty that removes additive position effects on the selected score scale.

2. **Comparison with composition.** The tool fits a frequency baseline on
   held-out gene groups and summarizes its relationship to predictor scores.
   The pooled calibration is descriptive and differs from the study's
   cross-fitted calibration; it does not identify an internal learned mechanism.

3. **Distance profile.** Summarize the chosen contrast by membrane distance.

Why within-site and why calibrated, in one line each: comparing different residues
across sides confounds the charge with how constrained each residue is, and
comparing a noisy predictor with a near-deterministic baseline on self-normalised
scales mechanically favours the baseline.

Usage
-----
    python -m membrane_rule_audit --topology census.html --scores scores.tsv \\
        --score-direction higher-is-damaging --out results/

See README.md for the score-file formats and for how to add a new predictor.
"""

from __future__ import annotations

import argparse
import csv
import gzip
import json
import math
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

AMINO_ACIDS = "ACDEFGHIKLMNPQRSTVWY"
POSITIVE, NEGATIVE, AMBIGUOUS = set("KR"), set("DE"), set("H")
CHARGED = POSITIVE | NEGATIVE | AMBIGUOUS
DEFAULT_BINS = ((1, 5), (6, 10), (11, 15), (16, 30), (31, 60))
RULES = {
    "positive_charge_loss": ("loss", POSITIVE),
    "positive_charge_gain": ("gain", POSITIVE),
    "negative_charge_loss": ("loss", NEGATIVE),
    "negative_charge_gain": ("gain", NEGATIVE),
}
VARIANT = re.compile(r"^([A-Z])(\d+)([A-Z])$")


# --------------------------------------------------------------------- inputs

def load_topology(path: Path) -> dict:
    """Read a topology census: {accession: {sequence, tmds, loops, gene}}.

    Accepts the Oxford-MRC viewer HTML with an embedded PROTEINS_INLINE array, or
    a plain JSON file with the same record shape.
    """
    text = Path(path).read_text(encoding="utf-8-sig")
    if path.suffix.lower() in {".json"}:
        records = json.loads(text)
    else:
        match = re.search(r"const PROTEINS_INLINE = (\[.*?\]);", text, flags=re.S)
        if not match:
            raise ValueError("No embedded PROTEINS_INLINE array found in the topology file")
        records = json.loads(match.group(1))
    return {r["uniprot"]: r for r in records}


def flank_map(record: dict, max_distance: int) -> dict[int, tuple[int, int, int]]:
    """position -> (side, distance to nearest TMD edge, 1-based TMD index).

    Boundaries come from transmembrane coordinates rather than loop numbering,
    because censuses commonly skip loop indices where two segments abut.
    """
    ends = {t["end"]: i for i, t in enumerate(record["tmds"], start=1)}
    starts = {t["start"]: i for i, t in enumerate(record["tmds"], start=1)}
    out: dict[int, tuple[int, int, int]] = {}
    for loop in record["loops"].values():
        side = str(loop.get("location", "")).strip().lower()
        if side not in {"inside", "outside"}:
            continue
        side_index = 0 if side == "inside" else 1
        start, end = int(loop["start"]), int(loop["end"])
        borders = []
        if start - 1 in ends:
            borders.append((start - 1, ends[start - 1], -1))
        if end + 1 in starts:
            borders.append((end + 1, starts[end + 1], 1))
        for position in range(start, end + 1):
            best = None
            for boundary, tmd_index, direction in borders:
                distance = (position - boundary) if direction == -1 else (boundary - position)
                if 0 < distance <= max_distance and (best is None or distance < best[0]):
                    best = (distance, tmd_index)
            if best:
                out[position] = (side_index, best[0], best[1])
    return out


def load_scores(path: Path, columns: dict[str, str] | None = None) -> list[tuple]:
    """Read predictor scores as (accession, position, reference, alternate, score).

    Supported: .npz with arrays protein/position/ref_aa/alt_aa/score plus an
    `accessions` index; or a delimited text file, optionally gzipped. A text file
    needs an accession column, a score column, and either a `protein_variant`
    column like `R123W` or separate reference/position/alternate columns.
    """
    path = Path(path)
    if path.suffix == ".npz":
        blob = np.load(path, allow_pickle=False)
        accessions = list(blob["accessions"])
        alphabet = np.array(list("".join(blob["aa_alphabet"].tolist()))
                            if "aa_alphabet" in blob else list(AMINO_ACIDS))
        score_key = "score" if "score" in blob else (
            "am_pathogenicity" if "am_pathogenicity" in blob else None)
        if score_key is None:
            raise ValueError("No score array found in the .npz")
        return [(accessions[p], int(pos), str(alphabet[r]), str(alphabet[a]), float(s))
                for p, pos, r, a, s in zip(blob["protein"], blob["position"],
                                           blob["ref_aa"], blob["alt_aa"], blob[score_key])]

    columns = columns or {}
    opener = gzip.open if path.suffix == ".gz" else open
    rows = []
    with opener(path, "rt", encoding="utf-8-sig", newline="") as handle:
        sample = handle.readline()
        handle.seek(0)
        delimiter = "\t" if sample.count("\t") >= sample.count(",") else ","
        reader = csv.DictReader(handle, delimiter=delimiter)
        accession_col = columns.get("accession", "uniprot_id")
        score_col = columns.get("score", "score")
        variant_col = columns.get("variant", "protein_variant")
        for row in reader:
            accession = (row.get(accession_col) or "").strip()
            try:
                score = float(row.get(score_col))
            except (TypeError, ValueError):
                continue
            if variant_col in row and row.get(variant_col):
                match = VARIANT.fullmatch((row[variant_col] or "").strip().upper())
                if not match:
                    continue
                reference, position, alternate = match.group(1), int(match.group(2)), match.group(3)
            else:
                try:
                    position = int(row[columns.get("position", "position")])
                except (TypeError, ValueError, KeyError):
                    continue
                reference = (row.get(columns.get("reference", "ref")) or "").strip().upper()
                alternate = (row.get(columns.get("alternate", "alt")) or "").strip().upper()
            if reference in AMINO_ACIDS and alternate in AMINO_ACIDS and reference != alternate:
                rows.append((accession, position, reference, alternate, score))
    return rows


# ---------------------------------------------------------------- site tables

def build_sites(scores, proteins: dict, max_distance: int, flip: bool) -> dict:
    """Group scores by residue, keeping only flank positions that match the census."""
    maps = {a: flank_map(r, max_distance) for a, r in proteins.items()}
    sites: dict = defaultdict(dict)
    context: dict = {}
    qc = defaultdict(int)
    for accession, position, reference, alternate, score in scores:
        record = proteins.get(accession)
        if record is None:
            qc["accession_not_in_census"] += 1
            continue
        sequence = record["sequence"]
        if position > len(sequence) or sequence[position - 1] != reference:
            qc["reference_mismatch"] += 1
            continue
        flank = maps[accession].get(position)
        if flank is None:
            continue
        key = (accession, position, reference)
        sites[key][alternate] = -score if flip else score
        context[key] = {"accession": accession, "gene": record.get("gene", accession),
                        "side": flank[0], "distance": flank[1], "tmd_index": flank[2]}
        qc["kept"] += 1
    return {"sites": sites, "context": context, "qc": dict(qc)}


def penalties(table: dict, kind: str, group: set[str]) -> list[dict]:
    """Within-site charge penalty, with charge reversals excluded from every arm.

    gain: reference uncharged, numerator introduces the charge, comparator stays uncharged.
    loss: reference carries the charge, numerator removes it, comparator swaps within the group.
    """
    out = []
    for key, alternates in table["sites"].items():
        reference = key[2]
        if kind == "gain":
            if reference in CHARGED:
                continue
            numerator = [v for a, v in alternates.items() if a in group]
            comparator = [v for a, v in alternates.items() if a not in CHARGED]
        else:
            if reference not in group:
                continue
            numerator = [v for a, v in alternates.items() if a not in CHARGED]
            comparator = [v for a, v in alternates.items() if a in group and a != reference]
        if not numerator or not comparator:
            continue
        info = table["context"][key]
        out.append({**info, "position": key[1], "reference": reference,
                    "penalty": float(np.mean(numerator)) - float(np.mean(comparator))})
    return out


# ----------------------------------------------------------------- estimation

def strata(rows: list[dict]) -> dict:
    """Per-(gene, reference residue) side contrasts, dropping single-sided cells."""
    buckets: dict = defaultdict(lambda: {"c": [], "o": []})
    for row in rows:
        buckets[(row["gene"], row["reference"])]["c" if row["side"] == 0 else "o"].append(
            row["penalty"])
    genes, weight, diff, used, dropped = [], [], [], 0, 0
    for (gene, _), arms in sorted(buckets.items()):
        n1, n0 = len(arms["c"]), len(arms["o"])
        if n1 == 0 or n0 == 0:
            dropped += n1 + n0
            continue
        genes.append(gene)
        weight.append(n1 * n0 / (n1 + n0))
        diff.append(float(np.mean(arms["c"]) - np.mean(arms["o"])))
        used += n1 + n0
    names = sorted(set(genes))
    index = {g: i for i, g in enumerate(names)}
    return {"cluster": np.array([index[g] for g in genes], dtype=int),
            "weight": np.array(weight), "diff": np.array(diff), "genes": names,
            "n_contributing_sites": used, "n_dropped_single_sided": dropped}


def point_and_interval(block: dict, draws: int, seed: int) -> dict:
    if block["diff"].size < 2:
        return {"estimate": None, "ci95": [None, None], "n_strata": int(block["diff"].size)}
    weight, diff = block["weight"], block["diff"]
    estimate = float((weight * diff).sum() / weight.sum())
    rng = np.random.default_rng(seed)
    n = len(block["genes"])
    samples = np.empty(draws)
    for i in range(draws):
        counts = np.bincount(rng.integers(0, n, n), minlength=n).astype(float)
        m = counts[block["cluster"]]
        total = (weight * m).sum()
        samples[i] = float((weight * m * diff).sum() / total) if total > 0 else np.nan
    finite = samples[np.isfinite(samples)]
    return {"estimate": estimate,
            "ci95": [float(np.percentile(finite, 2.5)), float(np.percentile(finite, 97.5))]
            if finite.size > 1 else [None, None],
            "n_strata": int(diff.size), "n_genes": n,
            "n_contributing_sites": block["n_contributing_sites"],
            "n_dropped_single_sided": block["n_dropped_single_sided"]}


def composition_baseline(table: dict, bins, folds: int, seed: int) -> dict:
    """Frequency baseline B1: log f(reference | side, bin) - log f(alternate | side, bin).

    Fitted on training families only and scored out of fold. Families are the gene
    symbols present in the census; pass a richer clustering if you have one.
    """
    keys = sorted(table["sites"])
    families = sorted({table["context"][k]["gene"] for k in keys})
    rng = np.random.default_rng(seed)
    fold_of = {f: int(rng.integers(0, folds)) for f in families}

    def bin_of(distance: int) -> int:
        for i, (low, high) in enumerate(bins):
            if low <= distance <= high:
                return i
        return -1

    index = {a: i for i, a in enumerate(AMINO_ACIDS)}
    scored: dict = defaultdict(dict)
    for held in range(folds):
        counts = np.full((2, len(bins), 20), 0.5)
        for key in keys:
            info = table["context"][key]
            if fold_of[info["gene"]] == held:
                continue
            bucket = bin_of(info["distance"])
            if bucket >= 0:
                counts[info["side"], bucket, index[key[2]]] += 1.0
        logf = np.log(counts / counts.sum(axis=2, keepdims=True))
        for key in keys:
            info = table["context"][key]
            if fold_of[info["gene"]] != held:
                continue
            bucket = bin_of(info["distance"])
            if bucket < 0:
                continue
            for alternate in table["sites"][key]:
                scored[key][alternate] = float(
                    logf[info["side"], bucket, index[key[2]]]
                    - logf[info["side"], bucket, index[alternate]])
    return {"sites": scored, "context": table["context"], "qc": {}}


def calibrated_residual(predictor_rows, baseline_rows, draws: int, seed: int) -> dict:
    """How much of the side difference the predictor's own use of composition implies.

    Regress predictor penalties on baseline penalties over all shared sites, then
    compare the observed side difference with slope x the baseline's. The residual
    is side-specific over- or under-use of the footprint. Predictor noise does not
    bias this, and the baseline being near-deterministic is an asset in a regressor.
    """
    key = lambda r: (r["accession"], r["position"], r["reference"])
    left = {key(r): r for r in predictor_rows}
    right = {key(r): r for r in baseline_rows}
    shared = sorted(set(left) & set(right))
    if len(shared) < 50:
        return {"note": "too few shared sites", "n_shared": len(shared)}
    y = np.array([left[k]["penalty"] for k in shared])
    x = np.array([right[k]["penalty"] for k in shared])
    design = np.column_stack([np.ones(len(x)), x])
    coefficients, *_ = np.linalg.lstsq(design, y, rcond=None)
    slope = float(coefficients[1])

    predictor_block = strata([left[k] for k in shared])
    baseline_block = strata([right[k] for k in shared])
    if predictor_block["diff"].size != baseline_block["diff"].size:
        return {"note": "stratum sets differ", "slope": slope}
    residual = predictor_block["diff"] - slope * baseline_block["diff"]
    weight = predictor_block["weight"]
    rng = np.random.default_rng(seed)
    n = len(predictor_block["genes"])
    samples = np.empty(draws)
    for i in range(draws):
        counts = np.bincount(rng.integers(0, n, n), minlength=n).astype(float)
        m = counts[predictor_block["cluster"]]
        total = (weight * m).sum()
        samples[i] = float((weight * m * residual).sum() / total) if total > 0 else np.nan
    finite = samples[np.isfinite(samples)]
    return {
        "slope_on_composition": slope,
        "observed_side_difference": float((weight * predictor_block["diff"]).sum() / weight.sum()),
        "implied_by_calibration": float(slope * (weight * baseline_block["diff"]).sum() / weight.sum()),
        "residual": float((weight * residual).sum() / weight.sum()),
        "residual_ci95": [float(np.percentile(finite, 2.5)), float(np.percentile(finite, 97.5))]
        if finite.size > 1 else [None, None],
        "n_shared_sites": len(shared), "n_strata": int(residual.size), "n_genes": n,
    }


# ----------------------------------------------------------------------- main

def run_audit(topology: Path, scores_path: Path, flip: bool, out_dir: Path,
              max_distance: int = 60, bins=DEFAULT_BINS, folds: int = 5,
              draws: int = 1000, seed: int = 0, columns=None) -> dict:
    proteins = load_topology(Path(topology))
    raw = load_scores(Path(scores_path), columns)
    table = build_sites(raw, proteins, max_distance, flip)
    baseline = composition_baseline(table, bins, folds, seed)

    results: dict = {}
    for rule, (kind, group) in RULES.items():
        rows = penalties(table, kind, group)
        base_rows = penalties(baseline, kind, group)
        near = [r for r in rows if r["distance"] <= bins[1][1]]
        results[rule] = {
            "side_difference_all": point_and_interval(strata(rows), draws, seed),
            "side_difference_near": point_and_interval(strata(near), draws, seed),
            "by_distance_bin": {
                f"{low}-{high}": point_and_interval(
                    strata([r for r in rows if low <= r["distance"] <= high]), draws, seed)
                for low, high in bins
            },
            "cytosolic_mean_penalty_by_bin": {
                f"{low}-{high}": (float(np.mean([r["penalty"] for r in rows
                                                 if r["side"] == 0 and low <= r["distance"] <= high]))
                                  if any(r["side"] == 0 and low <= r["distance"] <= high for r in rows)
                                  else None)
                for low, high in bins
            },
            "calibrated_vs_composition": calibrated_residual(rows, base_rows, draws, seed),
        }

    summary = {
        "tool": "membrane_rule_audit",
        "as_of_utc": datetime.now(timezone.utc).isoformat(),
        "topology": str(topology), "scores": str(scores_path),
        "score_direction": "higher is more damaging"
        + (" (input was flipped)" if flip else " (input taken as given)"),
        "max_distance": max_distance, "bins": [list(b) for b in bins],
        "folds": folds, "bootstrap_draws": draws, "seed": seed,
        "input_quality_control": table["qc"],
        "sign_convention": "Side difference is cytosolic minus outer. Positive means the "
                           "predictor calls the change more damaging on the cytosolic side.",
        "results": results,
    }
    out_dir = Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "membrane_rule_audit.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--topology", required=True, help="census HTML or JSON")
    parser.add_argument("--scores", required=True, help=".npz, .tsv, .csv, optionally .gz")
    parser.add_argument("--score-direction", required=True,
                        choices=("higher-is-damaging", "higher-is-tolerated"),
                        help="declare it; the tool will not guess")
    parser.add_argument("--out", required=True)
    parser.add_argument("--max-distance", type=int, default=60)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--draws", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--accession-column", default="uniprot_id")
    parser.add_argument("--score-column", default="score")
    parser.add_argument("--variant-column", default="protein_variant")
    args = parser.parse_args()

    summary = run_audit(
        Path(args.topology), Path(args.scores),
        flip=(args.score_direction == "higher-is-tolerated"),
        out_dir=Path(args.out), max_distance=args.max_distance,
        folds=args.folds, draws=args.draws, seed=args.seed,
        columns={"accession": args.accession_column, "score": args.score_column,
                 "variant": args.variant_column})

    print(f"sites kept: {summary['input_quality_control'].get('kept', 0):,}")
    print(f"{'rule':<24}{'side diff':>12}{'95% CI':>22}{'slope':>9}{'residual':>11}  genes")
    for rule, block in summary["results"].items():
        side = block["side_difference_all"]
        cal = block["calibrated_vs_composition"]
        if side["estimate"] is None:
            print(f"{rule:<24}{'n/a':>12}")
            continue
        ci = f"[{side['ci95'][0]:+.3f},{side['ci95'][1]:+.3f}]"
        slope = cal.get("slope_on_composition")
        residual = cal.get("residual")
        slope_text = f"{slope:+9.3f}" if slope is not None else f"{'n/a':>9}"
        residual_text = f"{residual:+11.4f}" if residual is not None else f"{'n/a':>11}"
        print(f"{rule:<24}{side['estimate']:+12.4f}{ci:>22}{slope_text}{residual_text}"
              f"  {side.get('n_genes', 0)}")


if __name__ == "__main__":
    main()
