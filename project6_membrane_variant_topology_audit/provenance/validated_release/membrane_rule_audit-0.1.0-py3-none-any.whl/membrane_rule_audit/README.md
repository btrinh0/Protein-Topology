# membrane_rule_audit

Reusable within-site comparisons of mutation scores near membrane boundaries. Supply released predictor scores and a topology census, or an already mapped flank-score archive. The tool reports the specified contrast, contributing counts and machine-readable outputs.

## Install and run

From the project root:

```text
python -m pip install ./tools
membrane-rule-audit --topology census.json --scores scores.tsv --score-direction higher-is-damaging --out results/my_model
```

Without installation, the general command is:

```text
python -m tools.membrane_rule_audit --topology census.json --scores scores.tsv --score-direction higher-is-damaging --out results/my_model
```

Only NumPy and Python 3.10 or newer are required. Score direction is mandatory: `higher-is-damaging` or `higher-is-tolerated`. A direction change negates the input before estimating contrasts.

## Small known-answer example

Generate the included synthetic input from the project root:

```text
python examples/generate_toy_example.py
membrane-rule-audit --topology examples/toy/toy_topology.json --scores examples/toy/toy_scores.tsv --score-direction higher-is-damaging --out results/toy_general
membrane-rule-panel --scores examples/toy/toy_mapped_scores.npz --model SyntheticExample --score-direction higher-is-damaging --out results/toy_panel
```

Both gain outputs should be −0.30 in raw score units. The input has two artificial proteins and 608 variants; it contains no patient or real predictor data. Changing declared score direction flips the contrast.

The general command's legacy console label `sites kept` counts retained scored variant rows. This toy has 32 native positions and 16 eligible gain sites; the mapped panel reports eligible and contributing position counts separately. Use those position counts when describing the gain estimator's sample, rather than the 608 variant rows.

The [method validation](../../docs/METHOD_VALIDATION_20261006.md) records an actual wheel installation into an isolated environment, both installed commands, the API and source-byte checks, as well as the larger predeclared known-answer benchmark and shuffled-label controls. Plotting those benchmark results requires Matplotlib; the delivered tool requires only NumPy.

## General input format

CSV/TSV, optionally gzipped, with these columns:

```text
uniprot_id    protein_variant    score
P51681       R123W              0.84
```

Alternatively supply `ref`, `position`, `alt` columns. Column names can be overridden by the command options. NPZ inputs can contain `accessions`, `protein`, `position`, `ref_aa`, `alt_aa`, `score` (or `am_pathogenicity`), and `aa_alphabet`. Protein and amino-acid indices are zero-based; native positions are one-based.

The topology input is the project's viewer HTML with embedded `PROTEINS_INLINE`, or a JSON array such as:

```json
[{"uniprot":"P51681","gene":"CCR5","sequence":"MDYQ...","tmds":[{"start":55,"end":75}],"loops":{"1":{"start":1,"end":54,"location":"inside"}}}]
```

Loop location is `inside` for cytosolic or `outside` for outer. References must agree with the census sequence. The general interface computes positive-charge gain/loss and negative-charge gain/loss, excluding charge reversals and histidine. Distance bins and contributing/dropped counts are included.

Its composition output is a descriptive pooled calibration using gene groups, rather than the study's cross-fitted calibration using sequence-similarity groups. It is not an exact reproduction of the study's fitted slope or a validated model-correctness test. A matching shared-site key includes the native position so different residues in one protein remain distinct.

## Precomputed panel interface

```text
membrane-rule-panel --scores flank_scores.npz --model MyPredictor --score-direction higher-is-damaging --out results/my_model
```

The mapped NPZ format additionally requires per-variant `side` (0 cytosolic, 1 outer), `distance`, and `tmd_index`. The alphabet is `ACDEFGHIKLMNPQRSTVWY`. Identical duplicates are combined; conflicting scores or site metadata are rejected.

This interface packages the earlier raw K/R-gain comparison with the all-uncharged comparator `ACFGILMNPQSTVWY`. Synonymous alternatives are excluded. It contrasts charged and uncharged substitutions at each eligible uncharged reference, then computes a harmonic-size-weighted cytosolic-minus-outer difference within protein/reference strata. One-sided strata do not contribute. The default window is ten residues.

The saved JSON includes source and implementation hashes, direction, settings, counts and the point estimate. With at least two contributing proteins, the default 1,999 draws supply a protein-resampling stability interval. Such an interval does not by itself establish independent-family or clinical generalization.

## Python API and two-model demonstration

```python
from membrane_rule_audit import run_panel_audit

summary = run_panel_audit(
    "flank_scores.npz", "results/my_model", "MyPredictor",
    "higher-is-damaging",
)
```

Run `python scripts/run_rule_audit.py` from the project root to apply this same function to AlphaMissense and ESM1b. The two-model demonstration uses raw scores, the original comparator and the original ten-residue window. No alternative-comparator, transformed-scale, context or simulation checks are invoked.

## Scope

Within-site subtraction removes additive position effects on the selected score scale. It does not isolate charge from every property of an amino-acid substitution. Report the comparator, score direction and units with the result.

The package demonstrates reusable score analysis. It does not determine an internal learned mechanism, insertion energy, clinical harm, or which predictor is biologically correct. The scientific history is retained separately in the project's decision log.
